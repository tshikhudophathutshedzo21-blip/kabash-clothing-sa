# KABASH Clothing — Free Website

Open `index.html` to preview the website.

Before publishing, replace/add your real product photos and social links.
The WhatsApp number is already set to 082 302 5616.

For a free public website, upload `index.html` to a free static-hosting service such as GitHub Pages or Netlify.
